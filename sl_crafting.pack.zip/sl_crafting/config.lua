Config = {}

-- Bench locations
Config.Benches = {
    {coords = vector3(-2215.99, 282.81, 184.6), heading = 90.0, name = "Downtown Bench"},
    {coords = vector3(-477.77, 5304.43, 80.61), heading = 90.0, name = "Sawmil Bench"},
    {coords = vector3(1711.5, 3846.25, 34.93), heading = 90.0, name = "Sandy Bench"},
    {coords = vector3(2843.34, 1439.64, 32.6), heading = 90.0, name = "Powerlocation Bench"},
}

Config.Crafting = {
    ["medical"] = {
        ["bandage"] = {
            items = {
                {name = "rubber", amount = 2},
                {name = "plastic", amount = 1}
            },
            time = 3000,
            description = "🩹 **Bandage** – Heal minor injuries and stay in the fight! Required Items: 2x Rubber, 1x Plastic.",
            failChance = 0.05,
            minPlayerLevel = 0,
            xpGain = 5,
            emoji = "🩹"
        }
    },

    ["weapons"] = { -- 📂 Weapons Category
        categories = {
            ["rifles"] = {
                label = "🎯 Rifles",
                items = {
                    ["weapon_assaultrifle"] = {
                        items = {
                            {name = "metalscrap", amount = 50},
                            {name = "steel", amount = 30},
                            {name = "plastic", amount = 15}
                        },
                        time = 15000,
                        description = "🔫 **Assault Rifle** – Rapid-fire automatic rifle for infantry use.",
                        failChance = 0.2,
                        minPlayerLevel = 10,
                        xpGain = 70,
                        emoji = "🔫"
                    },
                    ["weapon_assaultrifle_mk2"] = {
                        items = {
                            {name = "metalscrap", amount = 55},
                            {name = "steel", amount = 35},
                            {name = "plastic", amount = 18}
                        },
                        time = 16000,
                        description = "🔫 **Assault Rifle Mk II** – Upgraded Assault Rifle with better performance.",
                        failChance = 0.25,
                        minPlayerLevel = 12,
                        xpGain = 80,
                        emoji = "🔫"
                    },
                    ["weapon_carbinerifle"] = {
                        items = {
                            {name = "metalscrap", amount = 50},
                            {name = "steel", amount = 32},
                            {name = "plastic", amount = 17}
                        },
                        time = 15500,
                        description = "🔫 **Carbine Rifle** – Lightweight automatic rifle, easy to handle.",
                        failChance = 0.22,
                        minPlayerLevel = 11,
                        xpGain = 72,
                        emoji = "🔫"
                    },
                    ["weapon_carbinerifle_mk2"] = {
                        items = {
                            {name = "metalscrap", amount = 55},
                            {name = "steel", amount = 36},
                            {name = "plastic", amount = 20}
                        },
                        time = 16500,
                        description = "🔫 **Carbine Rifle Mk II** – Upgraded Carbine Rifle with improved stats.",
                        failChance = 0.26,
                        minPlayerLevel = 13,
                        xpGain = 78,
                        emoji = "🔫"
                    },
                    ["weapon_advancedrifle"] = {
                        items = {
                            {name = "metalscrap", amount = 60},
                            {name = "steel", amount = 38},
                            {name = "plastic", amount = 22}
                        },
                        time = 17000,
                        description = "🔫 **Advanced Rifle** – Enhanced automatic rifle for serious combat.",
                        failChance = 0.28,
                        minPlayerLevel = 14,
                        xpGain = 85,
                        emoji = "🔫"
                    },
                    ["weapon_specialcarbine"] = {
                        items = {
                            {name = "metalscrap", amount = 62},
                            {name = "steel", amount = 40},
                            {name = "plastic", amount = 25}
                        },
                        time = 17500,
                        description = "🔫 **Special Carbine** – Extremely versatile rifle for any combat situation.",
                        failChance = 0.3,
                        minPlayerLevel = 15,
                        xpGain = 90,
                        emoji = "🔫"
                    },
                    ["weapon_specialcarbine_mk2"] = {
                        items = {
                            {name = "metalscrap", amount = 65},
                            {name = "steel", amount = 42},
                            {name = "plastic", amount = 28}
                        },
                        time = 18000,
                        description = "🔫 **Special Carbine Mk II** – Upgraded Special Carbine with higher accuracy.",
                        failChance = 0.32,
                        minPlayerLevel = 17,
                        xpGain = 95,
                        emoji = "🔫"
                    },
                    ["weapon_bullpuprifle"] = {
                        items = {
                            {name = "metalscrap", amount = 55},
                            {name = "steel", amount = 35},
                            {name = "plastic", amount = 20}
                        },
                        time = 16500,
                        description = "🔫 **Bullpup Rifle** – Compact automatic rifle for mobile combat.",
                        failChance = 0.27,
                        minPlayerLevel = 14,
                        xpGain = 82,
                        emoji = "🔫"
                    },
                    ["weapon_bullpuprifle_mk2"] = {
                        items = {
                            {name = "metalscrap", amount = 60},
                            {name = "steel", amount = 38},
                            {name = "plastic", amount = 22}
                        },
                        time = 17500,
                        description = "🔫 **Bullpup Rifle Mk II** – Upgraded Bullpup Rifle with improved performance.",
                        failChance = 0.3,
                        minPlayerLevel = 16,
                        xpGain = 88,
                        emoji = "🔫"
                    },
                    ["weapon_compactrifle"] = {
                        items = {
                            {name = "metalscrap", amount = 48},
                            {name = "steel", amount = 30},
                            {name = "plastic", amount = 15}
                        },
                        time = 15000,
                        description = "🔫 **Compact Rifle** – Smaller version of an assault rifle, lightweight.",
                        failChance = 0.23,
                        minPlayerLevel = 12,
                        xpGain = 75,
                        emoji = "🔫"
                    },
                    ["weapon_militaryrifle"] = {
                        items = {
                            {name = "metalscrap", amount = 65},
                            {name = "steel", amount = 45},
                            {name = "plastic", amount = 25}
                        },
                        time = 18500,
                        description = "🔫 **Military Rifle** – High-end rifle for advanced combat situations.",
                        failChance = 0.33,
                        minPlayerLevel = 18,
                        xpGain = 100,
                        emoji = "🔫"
                    }
                }
            },                                  

            ["melee"] = {
                label = "🔪 Melee Weapons",
                items = {
                    ["weapon_knife"] = {
                        items = {
                            {name = "metalscrap", amount = 10},
                            {name = "steel", amount = 5}
                        },
                        time = 5000,
                        description = "🔪 **Knife** – A close combat blade. Required Items: 10x Metal Scrap, 5x Steel.",
                        failChance = 0.1,
                        minPlayerLevel = 2,
                        xpGain = 15,
                        emoji = "🔪"
                    },
                    ["weapon_bat"] = {
                        items = {
                            {name = "wood", amount = 15},
                            {name = "steel", amount = 2}
                        },
                        time = 6000,
                        description = "🏏 **Baseball Bat** – A classic blunt weapon. Required Items: 15x Wood, 2x Steel.",
                        failChance = 0.12,
                        minPlayerLevel = 2,
                        xpGain = 18,
                        emoji = "🏏"
                    }
                }
            },

            ["smgs"] = {
                label = "🔧 SMGs",
                items = {
                    ["weapon_microsmg"] = {
                        items = {
                            {name = "metalscrap", amount = 35},
                            {name = "steel", amount = 20},
                            {name = "plastic", amount = 15},
                            {name = "rubber", amount = 5}
                        },
                        time = 12000,
                        description = "🔧 **Micro SMG** – Compact automatic weapon, lightweight and fast firing.",
                        failChance = 0.2,
                        minPlayerLevel = 10,
                        xpGain = 45,
                        emoji = "🔫"
                    },
                    ["weapon_smg"] = {
                        items = {
                            {name = "metalscrap", amount = 40},
                            {name = "steel", amount = 25},
                            {name = "plastic", amount = 18},
                            {name = "rubber", amount = 6}
                        },
                        time = 13000,
                        description = "🔧 **SMG** – Standard handheld light machine gun, reliable in close combat.",
                        failChance = 0.22,
                        minPlayerLevel = 12,
                        xpGain = 48,
                        emoji = "🔫"
                    },
                    ["weapon_smg_mk2"] = {
                        items = {
                            {name = "metalscrap", amount = 45},
                            {name = "steel", amount = 28},
                            {name = "plastic", amount = 20},
                            {name = "rubber", amount = 8}
                        },
                        time = 14000,
                        description = "🔧 **SMG Mk II** – Upgraded SMG with better accuracy and damage.",
                        failChance = 0.25,
                        minPlayerLevel = 14,
                        xpGain = 55,
                        emoji = "🔫"
                    },
                    ["weapon_assaultsmg"] = {
                        items = {
                            {name = "metalscrap", amount = 50},
                            {name = "steel", amount = 30},
                            {name = "plastic", amount = 20},
                            {name = "rubber", amount = 10}
                        },
                        time = 15000,
                        description = "🔧 **Assault SMG** – Assault version of a handheld light machine gun.",
                        failChance = 0.28,
                        minPlayerLevel = 16,
                        xpGain = 60,
                        emoji = "🔧"
                    },
                    ["weapon_combatpdw"] = {
                        items = {
                            {name = "metalscrap", amount = 55},
                            {name = "steel", amount = 35},
                            {name = "plastic", amount = 22},
                            {name = "rubber", amount = 10}
                        },
                        time = 16000,
                        description = "🔧 **Combat PDW** – Compact personal defense weapon, high rate of fire.",
                        failChance = 0.3,
                        minPlayerLevel = 18,
                        xpGain = 65,
                        emoji = "🔫"
                    },
                    ["weapon_machinepistol"] = {
                        items = {
                            {name = "metalscrap", amount = 25},
                            {name = "steel", amount = 15},
                            {name = "plastic", amount = 10},
                            {name = "rubber", amount = 5}
                        },
                        time = 10000,
                        description = "🔫 **Tec-9** – Self-loading pistol capable of burst or fully automatic fire.",
                        failChance = 0.2,
                        minPlayerLevel = 11,
                        xpGain = 40,
                        emoji = "🔫"
                    },
                    ["weapon_minismg"] = {
                        items = {
                            {name = "metalscrap", amount = 30},
                            {name = "steel", amount = 18},
                            {name = "plastic", amount = 12},
                            {name = "rubber", amount = 6}
                        },
                        time = 11000,
                        description = "🔧 **Mini SMG** – Extremely compact SMG for close quarters combat.",
                        failChance = 0.22,
                        minPlayerLevel = 13,
                        xpGain = 45,
                        emoji = "🔫"
                    }
                }
            }  -- You can expand more: rifles, shotguns, snipers, etc.
        }
    },

    ["ammo"] = { -- 💥 Ammo types
        ["smg_ammo"] = {
            items = {
                {name = "metalscrap", amount = 5},
                {name = "gunpowder", amount = 3}
            },
            time = 5000,
            description = "🔫 **SMG Ammo** – High rate of fire requires steady supplies. Required Items: 5x Metal Scrap, 3x Gunpowder.",
            failChance = 0.12,
            minPlayerLevel = 2,
            xpGain = 12,
            emoji = "💥"
        },

        ["rifle_ammo"] = {
            items = {
                {name = "steel", amount = 6},
                {name = "gunpowder", amount = 4}
            },
            time = 6000,
            description = "🔫 **Rifle Ammo** – Power for your assault rifles. Required Items: 6x Steel, 4x Gunpowder.",
            failChance = 0.15,
            minPlayerLevel = 3,
            xpGain = 18,
            emoji = "💥"
        }
    },

    ["tools"] = {
        ["repairkit"] = {
            items = {
                {name = "metalscrap", amount = 10},
                {name = "plastic", amount = 5}
            },
            time = 5000,
            description = "🛠️ **Repair Kit** – Fix damaged vehicles quickly. Required Items: 10x Metal Scrap, 5x Plastic.",
            failChance = 0.1,
            minPlayerLevel = 1,
            xpGain = 10,
            emoji = "🛠️"
        },

        ["lockpick"] = {
            items = {
                {name = "metalscrap", amount = 5},
                {name = "aluminum", amount = 3}
            },
            time = 4000,
            description = "🔑 **Lockpick** – Unlock doors and vehicles discreetly. Required Items: 5x Metal Scrap, 3x Aluminum.",
            failChance = 0.05,
            minPlayerLevel = 2,
            xpGain = 15,
            emoji = "🔑"
        }
    }
}

-- XP required per level
Config.XPPerLevel = 50