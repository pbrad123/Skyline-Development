fx_version 'cerulean'
game 'gta5'

name 'blockparty_crafting'
author 'Skyline Development'
description 'Blockparty Crafting System'
version '1.0.0'

lua54 'yes'

-- 🔧 Shared config (editable)
shared_scripts {
    'config.lua'
}

-- 🖥 Client-side (locked)
client_scripts {
    'client.lua'
}

-- 🧠 Server-side (locked)
server_scripts {
    'server.lua'
}

-- 📦 Dependencies
dependencies {
    'qb-core',
    'qb-menu',
    'qb-target'
}

-- 🔒 Escrow: allow config edits
escrow_ignore {
    'config.lua'
}

dependency '/assetpacks'