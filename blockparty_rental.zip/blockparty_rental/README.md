# 🎉 Blockparty RP Car Rental System (QBCore)

Custom, advanced, and fully modular **NPC-based car rental system** built for QBCore servers.  
Clean UI, emoji-enhanced menus, multi-fuel support, multi-key integration, and optimized performance.

---

## 🚗 Features

- 🧍‍♂️ NPC-Based Rental & Return
- 📋 Clean emoji-enhanced rental menu
- 💵 Custom vehicle price + deposit system
- 🔁 Deposit refunded if vehicle is returned undamaged
- 🚘 Vehicle automatically deleted on return
- 🔐 Automatic vehicle key assignment & removal
- ⛽ Multi-Fuel Support:
  - LegacyFuel
  - lc_fuel
  - cdn-fuel
- 🎯 Multi Target Support:
  - qb-target
  - ox_target
- 📱 Multi Menu Support:
  - qb-menu
  - xm_menu
- 🔔 Multi Notification Support:
  - QBCore default
  - okokNotify
  - Codewave
  - rtx_notify
  - wasabi_notify
  - CodemAdvancedNotify
  - brutal_notify
  - mythic_notify
- 🔑 Multiple Vehicle Key Systems:
  - qb-vehiclekeys
  - wasabi_carlock
  - quasar_vehiclekeys
  - ak47_qb_vehiclekeys
- 🛡️ Anti-exploit rental protection
- 🧠 Smart fuel resource detection
- 🛠️ Debug mode included

---

# 🔗 Supported Resources

## 🎯 Target Systems
- https://github.com/qbcore-framework/qb-target
- https://github.com/overextended/ox_target

## 📋 Menu Systems
- https://github.com/qbcore-framework/qb-menu
- https://github.com/xMaddMackx/xm_menu

## 🔔 Notification Systems
- QBCore Default Notify
- https://okok.tebex.io/package/4724993
- https://docs.okokscripts.io/scripts/okoknotify
- https://github.com/JayMontana36/mythic_notify
- https://docs.wasabiscripts.com/wasabi-scripts/core-ui-series/wasabi_notify
- https://rtx.tebex.io/package/5402098
- https://brutal-scripts.tebex.io/package/5566383
- https://codewave-scripts.tebex.io/package/6321609
- https://codem.tebex.io/package/5399171

## ⛽ Fuel Systems
- https://github.com/InZidiuZ/LegacyFuel
- https://github.com/LeonardoSoares98/lc_fuel
- cdn-fuel

## 🔑 Vehicle Key Systems
- https://github.com/qbcore-framework/qb-vehiclekeys
- https://docs.wasabiscripts.com/wasabi-scripts/advanced-series/wasabi_carlock
- https://www.quasar-store.com/package/5269147
- https://docs.menanak47.com/qbcore/ak47_qb_vehiclekeys/installation

---

# 📦 Installation

### 1️⃣ Add Resource

Place the folder inside your server:
resources/blockparty_rental

---

### 2️⃣ Add To server.cfg
ensure blockparty_rental


---

### 3️⃣ Required Dependencies

Make sure these are installed and running:

- qb-core
- Target system (qb-target or ox_target)
- Menu system (qb-menu or xm_menu)
- Vehicle key system
- Optional fuel script

---

# ⚙️ Configuration

Edit `config.lua` to customize the system.

---

## 🗺️ Locations

Configure:
- NPC positions
- Vehicle spawn points
- Multiple rental hubs supported

---

## 🚘 Rental Vehicles

Each vehicle supports:
- Model name
- Display label
- Rental price
- Deposit amount

---

## ⛽ Fuel Script

```lua
Config.FuelScript = "legacyfuel"
-- Options:
-- legacyfuel
-- lc_fuel
-- cdn_fuel

🔔 Notification System
Config.Notify = "qbcore"
-- qbcore
-- okok
-- wasabi
-- rtx
-- brutal
-- codem
-- codewave
-- mythic

🎯 Target System
Config.Target = "qb-target"
-- qb-target
-- ox_target

📋 Menu System
Config.Menu = "qb-menu"
-- qb-menu
-- xm_menu
🔑 Vehicle Key System
Config.KeySystem = "qb-vehiclekeys"
-- qb-vehiclekeys
-- wasabi_carlock
-- quasar_vehiclekeys
-- ak47_qb_vehiclekeys

Usage

Approach a rental NPC.

Interact using your configured target system.

Select a vehicle from the rental menu.

Pay rental fee + deposit.

Keys are automatically assigned.

Return vehicle to the rental location.

Deposit refunded if vehicle is undamaged.

🛠️ Support

If you encounter issues:

Ensure dependencies are started before this resource.

Enable Debug mode in config.

Verify fuel script name matches exactly.

🚀 Performance

Fully optimized loops

No unnecessary threads

Minimal network usage

Compatible with high-population servers