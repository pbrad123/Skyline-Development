fx_version 'cerulean'
game 'gta5'

name 'blockparty_carrental'
description 'Blockparty RP - Custom and Unique Car Rental System for QB-Core'
version '1.0.0'

lua54 'yes'

-- 🔧 Shared Config (Editable)
shared_scripts {
    'config.lua'
}

-- 🖥 Client-side (Locked)
client_scripts {
    'client/main.lua'
}

-- 🧠 Server-side (Locked)
server_scripts {
    '@qb-core/server/shared.lua',
    'server/main.lua'
}

-- 📦 Dependencies
dependencies {
    'qb-core',
    'qb-menu',
    'qb-target',
    'qb-vehiclekeys'
}

-- 🔒 Escrow: Allow config editing
escrow_ignore {
    'config.lua'
}

dependency '/assetpacks'
dependency '/assetpacks'