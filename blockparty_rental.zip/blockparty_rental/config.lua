Config = {}

-- =========================================================
-- ⚙️ GENERAL SETTINGS
-- =========================================================
Config.NotifySystem = "okokNotify"           -- qbcore, okokNotify, codewave, rtx_notify, wasabi_notify, CodemAdvancedNotify, brutal_notify
Config.Target = "qb-target"             -- qb-target or ox_target
Config.MenuSystem = "xm_menu"           -- qb-menu or xm_menu
Config.KeySystem = "qb-vehiclekeys"     -- qb-vehiclekeys, wasabi_carlock, quasar_vehiclekeys, ak47_qb_vehiclekeys, qbx_vehiclekeys
Config.Debug = false
Config.FuelScript = "cdn_fuel" -- "legacyfuel" | "lc_fuel" | "cdn_fuel"

-- =========================================================
-- 💰 PAYMENT SETTINGS
-- =========================================================
Config.PaymentType = "bank"             -- "bank" or "cash" for paying rentals

-- =========================================================
-- 🔹 MAP BLIPS
-- =========================================================
Config.EnableBlips = true               -- true = show blips, false = hide blips
Config.Blip = {
    sprite = 227,
    color = 3,
    scale = 0.7,
    display = 4,
    shortRange = true
}

-- =========================================================
-- 📍 RENTAL LOCATIONS
-- =========================================================
Config.Locations = {
    {
        label = "Downtown Rental",
        coords = vector3(216.17, -806.55, 30.78),
        npc = `s_m_m_autoshop_01`,
        heading = 160.0,
        spawn = vector4(216.99, -801.95, 30.78, 67.97),
        blip = Config.Blip
    },
    {
        label = "Sandy Shores Rental",
        coords = vector3(1707.5, 3591.0, 35.5),
        npc = `s_m_m_autoshop_01`,
        heading = 270.0,
        spawn = vector4(1705.0, 3585.0, 35.5, 90.0),
        blip = Config.Blip
    }
}

-- =========================================================
-- 🚗 AVAILABLE RENTAL VEHICLES
-- =========================================================
Config.Cars = {
    { model = "comet2",  label = "Comet SR", price = 500, deposit = 200 },
    { model = "banshee", label = "Banshee",  price = 700, deposit = 300 },
    { model = "blista",  label = "Blista",   price = 300, deposit = 100 },
    { model = "sultan",  label = "Sultan RS", price = 600, deposit = 250 }
}

-- =========================================================
-- 🚙 DEFAULT SPAWN (fallback)
-- =========================================================
Config.SpawnCoords = vector4(217.09, -801.7, 30.78, 62.24)

-- =========================================================
-- DEBUG HELPER
-- =========================================================
function DebugPrint(msg)
    if Config.Debug then
        print("^3[CarRental DEBUG]^7 "..msg)
    end
end
