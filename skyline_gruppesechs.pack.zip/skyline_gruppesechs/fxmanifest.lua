fx_version 'cerulean'
game 'gta5'

name 'skyline_gruppesechs'
author 'Skyline Development'
description 'Custom Gruppe Sechs Job (QB-Core)'
version '1.9.0'

lua54 'yes'

-- 🔧 Shared config (editable)
shared_scripts {
    'config.lua'
}

-- 🖥 Client-side (locked)
client_scripts {
    'client.lua'
}

-- 🧠 Server-side (locked)
server_scripts {
    'server.lua'
}

-- 📦 Dependency
dependencies {
    'qb-core'
}

-- 🔒 Escrow: allow config edits
escrow_ignore {
    'config.lua'
}

dependency '/assetpacks'