Config = {}

-- NPC Setup
Config.NPCModel = "s_m_m_armoured_02"
Config.NPCSpawn = vector3(-197.08, -831.47, 30.76)
Config.NPCHeading = 70.0

-- NPC Blip
Config.NPCBlip = {
    enabled = true,
    sprite = 500,
    color = 5,
    scale = 0.8,
    name = "Gruppe Sechs Job"
}

-- Truck
Config.TruckModel = "stockade"
Config.TruckSpawn = vector4(-144.73, -825.21, 31.23, 355.92)

-- Fuel Type`System
Config.Fueltype = "cdn_fuel" -- "lc_fuel", "cdn_fuel", or "legacyfuel"

-- Payment
Config.PayPerBag = 3000
Config.TotalBags = 8

-- Bank Stops
Config.BankStops = {
    vector3(33.65, -1348.26, 29.5),
    vector3(-527.54, -1222.64, 18.45),
    vector3(-3040.99, 593.67, 7.91),
    vector3(-386.3, 6045.64, 31.5),
    vector3(-96.66, 6456.17, 31.46),
    vector3(1735.83, 6410.28, 35.04),
    vector3(263.71, 214.05, 101.68),
    vector3(946.63, 47.13, 81.1)
}

-- Drop-off
Config.DropOff = vector3(-142.92, -819.15, 31.4)