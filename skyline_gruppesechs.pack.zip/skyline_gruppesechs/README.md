# blockparty_gruppesech

**Author:** Blockparty Development  
**Version:** 1.6.0  
**Framework:** QBCore

## Description
Custom Gruppe Sechs cash transport job.

## Features
- NPC with qb-target
- NPC blip
- QB-Menu start/cancel mission
- Armored truck spawn
- Bank stops with bag objects and blips
- Progress bar for bag collection
- Payment for all truck occupants
- Cancel mission support
- Fully configurable in config.lua
- Multiple fuel system type support added

## Requirements
- QBCore Framework
- qb-target
- qb-menu

## Installation
1. Place in resources folder.
2. Add ensure blockparty_gruppesech in server.cfg
3. Ensure qb-target and qb-menu are installed

## Usage
- Go to NPC and interact
- Open QB-Menu to start mission
- Collect bags and return truck