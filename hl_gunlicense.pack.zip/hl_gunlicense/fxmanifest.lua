fx_version 'cerulean'
game 'gta5'

name 'hl_gunlicense'
description 'HighLife Gun License Test (ped + blip, fixed questions, cooldown)'
author 'GoodVibes Development'
version '1.4.0'

lua54 'yes'

-- 🔧 Shared config (editable)
shared_scripts {
    'config.lua'
}

-- 🖥 Client (locked)
client_scripts {
    'client.lua'
}

-- 🧠 Server (locked)
server_scripts {
    'server.lua'
}

-- 🔒 Escrow: allow config edits
escrow_ignore {
    'config.lua'
}

dependency '/assetpacks'