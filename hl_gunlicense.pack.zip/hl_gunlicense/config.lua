Config = {}

-- 🔹 Target / Inventory Type
Config.TargetType    = "qb"     -- Options: "qb" or "ox"
Config.InventoryType = "qb"     -- Options: "qb" or "ox"

-- 🔹 Ped & Blip
Config.UsePed       = true
Config.PedModel     = "s_m_m_security_01"                 
Config.PedCoords    = vector4(15.91, -1105.87, 29.11, 174.57) 

Config.UseBlip      = true
Config.Blip = {
    Sprite = 110,
    Color  = 5,
    Scale  = 0.8,
    Label  = "Gun License Test"
}

-- 🔹 Test Rules
Config.LicenseMetaKey  = "weaponlicense"  
Config.LicenseFee      = 500              
Config.CooldownMinutes = 15               
Config.PassPercent     = 70               

-- 🔹 Questions
Config.Questions = {
    {
        question = "What is the legal age to purchase a firearm?",
        answers  = { "16 years old", "18 years old", "21 years old" },
        correct  = 3
    },
    {
        question = "When is it legal to discharge a firearm?",
        answers  = { "Anytime you want", "To scare someone", "At a licensed range or lawful self-defense" },
        correct  = 3
    },
    {
        question = "Where should your finger be placed until you are ready to fire?",
        answers  = { "On the trigger", "Outside the trigger guard", "On the safety switch" },
        correct  = 2
    },
    {
        question = "What’s the first rule of gun safety?",
        answers  = { "Always treat every gun as loaded", "Only point it at safe walls", "Guns are safe if not yours" },
        correct  = 1
    },
    {
        question = "Before cleaning a firearm, you should:",
        answers  = { "Leave it loaded", "Make sure it’s unloaded", "Dry fire a few times" },
        correct  = 2
    },
    {
        question = "How should firearms be stored when not in use?",
        answers  = { "On the car dashboard", "Under a pillow", "Locked case/safe, secured from others" },
        correct  = 3
    }
}
-- Add your own questions as needed