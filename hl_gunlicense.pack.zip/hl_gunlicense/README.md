hl_gunlicense

HighLife Gun License Test for QBCore-based FiveM servers.

Provides a ped-based firearms license test with a blip (toggleable), multiple-choice questions, bank payment, and cooldowns. All configuration is handled in config.lua.

Features

Ped spawns at configurable coordinates.

Toggleable blip for location.

Customizable multiple-choice questions (all asked every attempt).

Bank fee to take the test.

Pass/fail system with cooldown on failure.

QBCore metadata update on passing (weaponlicense by default).

Fully configurable via config.lua.

Compatible with qb-target and qb-menu.

Installation

Place the hl_gunlicense folder in your server resources folder, e.g., resources/[hl]/hl_gunlicense.

Add the following line to your server.cfg:

ensure hl_gunlicense


Make sure your server has the following dependencies:

qb-core

qb-target

qb-menu

Configuration (config.lua)

Ped & Blip

Config.PedModel      -- ped model name
Config.PedCoords     -- ped coordinates + heading
Config.UsePed        -- true/false
Config.UseBlip       -- true/false
Config.Blip.Sprite   -- blip icon
Config.Blip.Color    -- blip color
Config.Blip.Scale    -- blip scale
Config.Blip.Label    -- blip label text


Test Rules

Config.LicenseMetaKey  -- QBCore metadata key to set on pass
Config.LicenseFee      -- cost in bank to start test
Config.CooldownMinutes -- cooldown after failing
Config.PassPercent     -- % of correct answers required to pass


Questions

Config.Questions = {
    {
        question = "Question text",
        answers  = { "Answer 1", "Answer 2", "Answer 3" },
        correct  = 2 -- 1-based index of correct answer
    },
    ...
}

Usage

Approach the ped or target it using qb-target.

Select "Take Firearms License Test."

Pay the fee to start.

Answer all multiple-choice questions in order.

If you pass, your QBCore metadata will be updated with the gun license.
If you fail, you must wait the configured cooldown before trying again.

Notes

All questions are asked in order, every attempt (no randomization).

The system does not revoke licenses; once granted, they stay in metadata.

Can be expanded with more questions or custom logic in config.lua.

License

Free to use and modify for your FiveM server. Give credit if sharing publicly.

#### Ox_inventory Item Setup for the script ####
['weaponlicense'] = {
    label = 'Firearms License',
    stack = false,                -- Only one per slot / cannot stack
    weight = 50,                  -- Adjust weight as needed
    client = {
        image = 'weapon_license.png'  -- Make sure this image exists in your inventory UI folder
    },
},